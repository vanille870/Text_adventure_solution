#pragma once

class Exit;

void ChangExitAcces(Exit InputExit, bool InputExitOpen);


