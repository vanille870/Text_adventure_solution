#include <iostream>
#include <map>
#include <WorldObjects_Declarations.h>

void CreateMapOfObjects(WorldObjectManager* InputObjectManagerP)
{
	
}