#pragma once
#include <iostream>

class Navigator;
class LocationMap;

void PickDirection(Navigator* InputNavigator, LocationMap* InputLocationMap);