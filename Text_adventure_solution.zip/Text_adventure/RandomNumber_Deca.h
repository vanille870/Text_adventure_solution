#pragma once

int MakeRandomNumber(int InputMin, int InputMax);
